%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Clean Professional Version with Keywords & Title fix
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{LTJournalArticle}[2025/04/26 Clean Header + Keywords]

\usepackage{etoolbox}
\usepackage{hyperref}
\newtoggle{unnumberedsections}
\settoggle{unnumberedsections}{false}
\DeclareOption{unnumberedsections}{\settoggle{unnumberedsections}{true}}
\DeclareOption*{\PassOptionsToClass{\CurrentOption}{article}}
\ProcessOptions\relax

\LoadClass{article}

%--------------------------------------------------
% PACKAGES
%--------------------------------------------------

\usepackage{graphicx}
\graphicspath{{Figures/}{./}}

\usepackage[bottom, hang]{footmisc}
\setlength{\footnotemargin}{6pt}

\usepackage[
	top=2.5cm,
	bottom=2.5cm,
	left=2cm,
	right=2cm,
	footskip=1cm,
	headsep=1.5cm, % MORE SPACE for header/title
	columnsep=20pt,
]{geometry}

\usepackage[utf8]{inputenc}
\usepackage[T1]{fontenc}
\usepackage[sc]{mathpazo}
\linespread{1.05}
\usepackage{microtype}

\usepackage{fancyhdr}
\pagestyle{fancy}

\usepackage{titlesec}

\iftoggle{unnumberedsections}{
	\setcounter{secnumdepth}{0}
}{
	\setcounter{secnumdepth}{2}
}

\titleformat{\section}
	[block]
	{\Large\bfseries\raggedright}
	{\thesection}
	{0.5em}
	{}
	[]

\titleformat{\subsection}
	[block]
	{\raggedright\large\bfseries}
	{\thesubsection}
	{0.5em}
	{}
	[]

\titleformat{\subsubsection}
	[runin]
	{\bfseries}
	{}
	{5pt}
	{}
	[]

\titlespacing*{\subsubsection}{0pt}{0.5\baselineskip}{8pt}

\usepackage{titling}
\setlength{\droptitle}{0.3cm} % Reduced space before the title

\pretitle{\begin{center}\Huge\bfseries}
\posttitle{\end{center}}

\patchcmd{\maketitle}{plain}{fancy}{}{}

\usepackage{abstract}
\renewcommand{\abstractnamefont}{\normalfont\bfseries\vspace{0.5\baselineskip}}
\renewcommand{\abstracttextfont}{\vspace{-0.5\baselineskip}\normalfont\small\itshape}


% Define KEYWORDS
\newcommand{\keywords}[1]{%
    \vspace{-0.5\baselineskip}
    \noindent\normalfont\small\itshape{\textbf{Keywords:}} #1
    \vspace{1em}
}

\usepackage[
	backend=biber,
	citestyle=numeric,
	bibstyle=numeric,
	sorting=none,
]{biblatex}

\usepackage{booktabs}
\usepackage{array}
\newcolumntype{R}[1]{>{\raggedleft\arraybackslash}p{#1}}
\newcolumntype{L}[1]{>{\raggedright\arraybackslash}p{#1}}
\newcolumntype{C}[1]{>{\centering\arraybackslash}p{#1}}

\usepackage{caption}
\captionsetup{skip=6pt}
\captionsetup{labelfont={bf,small}, textfont={it,small}}

\usepackage{enumitem}
\setlist{noitemsep}

\usepackage{hyperref}
\hypersetup{
	colorlinks=true,
	urlcolor=black,
	linkcolor=black,
	citecolor=black,
}

%--------------------------------------------------
% CUSTOM HEADER AND FOOTER (CLEAN STYLE)
%--------------------------------------------------

\fancyhf{} % Clear header and footer

% Header
\fancyhead[L]{%
    \includegraphics[height=1.2cm]{ncitislogo26.png}%
}
\fancyhead[R]{%
    \textbf{\small NCITIS26, 13-14 December 2026, Batna-Algeria}
}

% Footer
\newcommand{\ShortTitle}{Short Title} % <-- You can change "Short Title" to whatever abbreviation you want
\renewcommand{\footrulewidth}{0.4pt} % Optional: a nice line above the footer

\fancyfoot[L]{\small\ShortTitle}
\fancyfoot[C]{\small Vide}
\fancyfoot[R]{\small\thepage}

%--------------------------------------------------
% CUSTOM COMMANDS
%--------------------------------------------------

\newcommand{\runninghead}[1]{\renewcommand{\runninghead}{#1}}
\newcommand{\footertext}[1]{\renewcommand{\footertext}{#1}}
